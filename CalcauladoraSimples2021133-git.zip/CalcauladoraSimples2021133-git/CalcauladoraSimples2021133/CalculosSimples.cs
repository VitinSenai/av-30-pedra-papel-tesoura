﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class CalculosSimples
{
    public double Somar(double numero1, double numero2)
    {
        double soma = numero1 + numero2;
        return soma;
    }

    
}
